var indexSectionsWithContent =
{
  0: "abcdefilmnoprstuxyz",
  1: "m",
  2: "m",
  3: "abcdefimnprsuz",
  4: "blotxy",
  5: "m",
  6: "bcdfilmprstuz",
  7: "m",
  8: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "properties",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Properties",
  7: "Macros",
  8: "Pages"
};

