var searchData=
[
  ['initwithmappoint_3awithdelegate_3awithopenapikey_3a',['initWithMapPoint:withDelegate:withOpenAPIKey:',['../interface_m_t_map_reverse_geo_coder.html#ae55f5d71cdb5de7a5f1148bc3999cca3',1,'MTMapReverseGeoCoder']]],
  ['ismaptilepersistentcacheenabled',['isMapTilePersistentCacheEnabled',['../interface_m_t_map_view.html#ae0ce2f26e663a6aa98c80533be28dae2',1,'MTMapView']]]
];
