var searchData=
[
  ['deselectpoiitem_3a',['deselectPOIItem:',['../interface_m_t_map_view.html#a3091c333d6f3232d3f1149908016499f',1,'MTMapView']]],
  ['didreceivememorywarning',['didReceiveMemoryWarning',['../interface_m_t_map_view.html#a490ce5218b3667d8328a001588ffb1d6',1,'MTMapView']]]
];
