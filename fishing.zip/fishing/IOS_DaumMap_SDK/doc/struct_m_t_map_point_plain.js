var struct_m_t_map_point_plain =
[
    [ "x", "struct_m_t_map_point_plain.html#a1a8fb7eea867ec699b039b25b312c191", null ],
    [ "y", "struct_m_t_map_point_plain.html#a5de61b026cdfa66a36dc1fd481e6d04d", null ]
];