var struct_m_t_map_image_offset =
[
    [ "offsetX", "struct_m_t_map_image_offset.html#a7828eddac89a55058f0e1c003cf8362b", null ],
    [ "offsetY", "struct_m_t_map_image_offset.html#a3eaf907ce8ccbbf3044669a83c1410a9", null ]
];