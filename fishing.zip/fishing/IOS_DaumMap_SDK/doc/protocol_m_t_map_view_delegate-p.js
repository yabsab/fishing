var protocol_m_t_map_view_delegate_p =
[
    [ "mapView:openAPIKeyAuthenticationResultCode:resultMessage:", "protocol_m_t_map_view_delegate-p.html#a5ddb49462a23b488d2177763253000a0", null ],
    [ "mapView:centerPointMovedTo:", "protocol_m_t_map_view_delegate-p.html#af80c59926d6c0ef7fe3c260dac6732d9", null ],
    [ "mapView:finishedMapMoveAnimation:", "protocol_m_t_map_view_delegate-p.html#a388206bf78da5eab1a743d80d27e7242", null ],
    [ "mapView:zoomLevelChangedTo:", "protocol_m_t_map_view_delegate-p.html#a5f9d09a2803af2b928d0517d01dd4002", null ],
    [ "mapView:singleTapOnMapPoint:", "protocol_m_t_map_view_delegate-p.html#a2581843aeade5459aaede824cbdf87ae", null ],
    [ "mapView:doubleTapOnMapPoint:", "protocol_m_t_map_view_delegate-p.html#a507f9a64564692925aece78c7ad0cb8a", null ],
    [ "mapView:dragStartedOnMapPoint:", "protocol_m_t_map_view_delegate-p.html#a451660af6325f970b559d1aad0e8ad4f", null ],
    [ "mapView:dragEndedOnMapPoint:", "protocol_m_t_map_view_delegate-p.html#ab464dea4bd5ff7af9a1d06b08dadc5cd", null ],
    [ "mapView:longPressOnMapPoint:", "protocol_m_t_map_view_delegate-p.html#ab7230c8533241a83183a09715d48baba", null ],
    [ "mapView:updateCurrentLocation:withAccuracy:", "protocol_m_t_map_view_delegate-p.html#a9c5f23050507e5a43177fcea18ad243c", null ],
    [ "mapView:failedUpdatingCurrentLocationWithError:", "protocol_m_t_map_view_delegate-p.html#aee56f591c77539f5e8dd11f9c3bd27e3", null ],
    [ "mapView:updateDeviceHeading:", "protocol_m_t_map_view_delegate-p.html#a870eb550fd21f49d342afa8e1f94bc2f", null ],
    [ "mapView:selectedPOIItem:", "protocol_m_t_map_view_delegate-p.html#aa06ad9c5801343bc87b48e41c730cfb4", null ],
    [ "mapView:touchedCalloutBalloonOfPOIItem:", "protocol_m_t_map_view_delegate-p.html#a9207929328cb95c1d9c87d4a8e253785", null ],
    [ "mapView:touchedCalloutBalloonLeftSideOfPOIItem:", "protocol_m_t_map_view_delegate-p.html#a25e4e8734a4859eb055a38d180652f71", null ],
    [ "mapView:touchedCalloutBalloonRightSideOfPOIItem:", "protocol_m_t_map_view_delegate-p.html#a9d50137c7123ad824198fa52c02b4e3d", null ],
    [ "mapView:draggablePOIItem:movedToNewMapPoint:", "protocol_m_t_map_view_delegate-p.html#ab5989ca8f2e1247e7666b602f4626c0a", null ]
];