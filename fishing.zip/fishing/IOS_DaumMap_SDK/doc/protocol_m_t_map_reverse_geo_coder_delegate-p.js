var protocol_m_t_map_reverse_geo_coder_delegate_p =
[
    [ "MTMapReverseGeoCoder:foundAddress:", "protocol_m_t_map_reverse_geo_coder_delegate-p.html#a36ef9badbde315a866fc49d6b21527da", null ],
    [ "MTMapReverseGeoCoder:failedToFindAddressWithError:", "protocol_m_t_map_reverse_geo_coder_delegate-p.html#ad7eaeb846e73f20b48f64301ca4b12ba", null ]
];